package com.example;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.User;
import com.example.repository.UserRepository;

@SpringBootApplication
public class SpringSecurityAppApplication {

	@Autowired
	private UserRepository repository;
	
	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityAppApplication.class, args);
		System.out.println("spring security App started");
	}
	@PostConstruct
	public void initUsers() {
		List<User> users=Stream.of(
			new User(1,"Shilpi","Shilpi219","shilpi.kumari@omfysgroup.com"),
			new User(2,"Komal","Komal218","shilpi.kumari@omfysgroup.com"),
			new User(3,"Nidhi","Nidhi222","shilpi.kumari@omfysgroup.com"),
			new User(4,"Sonal","Sonal211","shilpi.kumari@omfysgroup.com")
		).collect(Collectors.toList());
		repository.saveAll(users);
	}

}
