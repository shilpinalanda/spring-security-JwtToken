                 ----------- Ways to implement spring security in spring boot application-------------
1. create 6 package named controller,entity,repositories,service,config,utils
2. create model class named User inside entity pkg
3. create an interface named UserRepository and extends JpaRepository inside repository pkg
4. create a class named SecurityConfig extends WebSecurityConfigureAdapter inside config package and 
   also annotate with @Configuration and @EnableWebSecurity annotation 
   - and override configure(AuthenticationManagerBuilder auth) method and call auth.userDetailsService(give name of uds)
   - and create a Bean method of PasswordEncoder 
5. create a class named CustomUserDetailsService implements UserDetailsService inside service pkg and override a method inside loadUserByUsername of UserDetails
   Autowire a class named UserRepository and call userRepository.findByUsername(username);
   - findByUsername () should be defined inside UserRepository Interface
   
                 ---------Ways to implement JwtToken in spring boot application----------
                 
1. Add jsonwebtoken dependencies

<dependency>
    <groupId>io.jsonwebtoken</groupId>
    <artifactId>jjwt</artifactId>
    <version>0.9.1</version>
</dependency>
                 
2. create JwtUtil class inside util package and copy code of JwtUtil class from the google
3. create 1 class enside entity package named AuthRequest with username and password attribute  
3. create 1 endpoint of post request inside controller pkg to generate token with request body 
   - autowire 2 class JwtUtil and AuthenticationManager
4. Add a bean method inside springSecurity named authenticatinManagerBean() with return type AuthenticationManager
5. to disable spring security for a particular mapping override a configure() method inside Spring Security class inside config pkg
6. Add authenticationManagerBean() method of type  AuthenticationManager inside SecurityConfig class
7. open postman hit token generation url keep method post add json body with username and password and after hitting we will get the token
8. copy token and go in header section give key as Authorization and value will be Bearer +space +paste token and change the method type and hit the url
9. create 1 package named filter and create a class inside it named JwtFilter and extends OncePerRequestFilter and override doFilterInteral method
10. add JwtFilter inside SecurityCnnfig and Autowired it add go inside configure method and add sessionpolicy afterauthenticated()
   

